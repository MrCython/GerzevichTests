from functools import partial
from os import name
from django.urls import path
from . import views 
from django.conf import settings
from django.conf.urls.static import static


urlpatterns = [
    path('',views.enter),
    path('news/',views.select),
    path('users/',views.users),
    path('groups/',views.groups),
    path('categories/',views.categories),
    path('questions/',views.questions),
    path('tests/',views.tests),
    path('posts/',views.posts),
    path('books/',views.books),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)