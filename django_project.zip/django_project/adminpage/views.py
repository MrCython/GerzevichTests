from os import name
from django.shortcuts import *
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponse,JsonResponse
from .models import models
from math import *

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ВХОД~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
def enter(request):
    if request.method=='GET':
        return render(request,'adminpage/enter.html',context={'answer':'Введите логин и пароль'})
    else:
        login=request.POST['login']
        password=request.POST['password']
        access=models.check_log_pass(login,password)
        if access:
            return redirect(f'news/?id={access}&hello')
        else:
            return render(request,'adminpage/enter.html',context={'answer':'Неверный логин или пароль или пользователь уже в сети'})
            
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~НОВОСТИ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
def select(request):
    if request.method=='GET':
        id=request.GET['id']
        if models.check_session(id):
            context={
                'id':id,
                'hello':('hello' in request.GET),
                'surname_name':models.get_surname_name(id).split(),
            }
            return render(request,'adminpage/news.html',context)
        else:
            return render(request,'403.html')
    else:
        if 'quit' in request.POST:
            id=request.POST['quit']
            models.quit(id)
            return redirect('/')

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ПОЛЬЗОВАТЕЛИ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
def users(request):
    if request.method=='GET':
        id=request.GET['id']
        if models.check_session(id):
            context={
                'id':id,
                'surname_name':models.get_surname_name(id).split(),
                'list_users':models.list_users(),
                'list_groups':models.list_groups(),
                'sort_by_group':(0,),
                'k':1,
            }
            context['limit']=[i for i in range(1,ceil(len(context['list_users'])/25)+1)]
            context['list_users']=context['list_users'][:25]
            return render(request,'adminpage/users.html',context)
        else:
            return render(request,'403.html')
    else:
        group='0'
        if 'update_user' in request.POST: #изменение данных пользователя 
            id,self_id,k,group=request.POST['update_user'].split('_')
            surname_name=request.POST['surname_name']
            login=request.POST['login']
            password=request.POST['password']
            rank=request.POST['rank']
            models.update_user(id,surname_name,login,password,rank)
        elif 'del_user' in request.POST: #удаление пользователя
            id,self_id,k,group=request.POST['del_user'].split('_')
            models.del_user(id)
            if id==self_id:
                return redirect('/admin/')
        elif 'del_session' in request.POST: #удаление сессии пользователя
            id,self_id,k,group=request.POST['del_session'].split('_')
            models.del_session(id,self_id)
        elif 'add_user' in request.POST:
            self_id,k,group=request.POST['add_user'].split('_')
            surname_name=request.POST['surname_name'].split('\r\n')
            rank=request.POST['rank']
            groups=request.POST.getlist('groups[]')
            models.add_user(surname_name,rank,groups)
            return redirect(f'/admin/users/?id={self_id}')
        elif 'delete_all' in request.POST:
            self_id,group=request.POST['delete_all'].split('_')
            k=1
            models.del_users_from_group(group)
        elif 'update_table' in request.POST:
            self_id,k,group=request.POST['update_table'].split('_')
        elif 'sort_by_groups' in request.POST:
            self_id,k,group=request.POST['sort_by_groups'].split('_')
            k=1
        context={
            'id':self_id,
            'surname_name':models.get_surname_name(self_id).split(),
            'list_users':models.list_users(int(group)),
            'list_groups':models.list_groups(),
            'sort_by_group':(int(group),),
            'k':k,
        }
        context['limit']=[str(i) for i in range(1,ceil(len(context['list_users'])/25)+1)]
        context['list_users']=context['list_users'][(int(k)-1)*25:int(k)*25]
        return render(request,'adminpage/users.html',context)

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ГРУППЫ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
def groups(request):
    if request.method=='GET':
        id=request.GET['id']
        if models.check_session(id):
            context={
                'id':id,
                'surname_name':models.get_surname_name(id).split(),
                'creator':models.get_surname_name(id),
                'list_groups':models.list_groups(),
            }
            return render(request,'adminpage/groups.html',context)
        else:
            return render(request,'403.html')
    else:
        if 'creat' in request.POST:
            id=request.POST['creat']
            name=request.POST['name']
            img=request.FILES.get('img')
            creator=request.POST['creator']
            users=request.POST['users']
            models.creat_group(name,img,creator,users)
            return redirect(f'/admin/groups/?id={id}')
        elif 'update' in request.POST:
            id_group,id=request.POST['update'].split('_')
            name=request.POST['name']
            img=request.FILES.get('img')
            del_avatar=request.POST.get('del_avatar',False)
            creator=request.POST['creator']
            users=request.POST['users']
            models.update_group(id_group,name,img,del_avatar,creator,users)
        elif 'delete' in request.POST:
            id_group,id=request.POST['delete'].split('_')
            creator=request.POST['creator']
            models.delete_group(id_group)
        context={
            'id':id,
            'surname_name':models.get_surname_name(id).split(),
            'creator':creator,
            'list_groups':models.list_groups(),
        }
        return render(request,'adminpage/groups.html',context)

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~КАТЕГОРИИ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
def categories(request):
    if request.method=='GET':
        id=request.GET['id']
        if models.check_session(id):
            context={
                'id':id,
                'surname_name':models.get_surname_name(id).split(),
                'list_objects':models.list_objects(),
                'list_topics':models.list_topics(),
                'list_types':models.list_types(),
            }
            return render(request,'adminpage/object_topic_type.html',context)
        else:
            return render(request,'403.html')
    else:
        open_object=('add_object' in request.POST or 'del_object' in request.POST)
        id_object=0
        open_topic=('add_topic' in request.POST or 'del_topic' in request.POST)
        id_topic=0
        open_type=('add_type' in request.POST or 'del_type' in request.POST)
        if 'add_object' in request.POST:
            self_id=request.POST['add_object']
            name_new_object=request.POST['name_new_object']
            models.add_object(name_new_object)
        elif 'del_object' in request.POST:
            id,self_id=request.POST['del_object'].split('_')
            models.del_object(id)
        elif 'add_topic' in request.POST:
            id_object,self_id=request.POST['add_topic'].split('_')
            name=request.POST['name_new_topic']
            models.add_topic(id_object,name)
        elif 'del_topic' in request.POST:
            id_topic,self_id=request.POST['del_topic'].split('_')
            id_object=models.del_topic(id_topic)
        elif 'add_type' in request.POST:
            id_topic,self_id=request.POST['add_type'].split('_')
            name=request.POST['name_new_type']
            models.add_type(id_topic,name)
        elif 'del_type' in request.POST:
            id_type,self_id=request.POST['del_type'].split('_')
            id_topic=models.del_type(id_type)
        context={
            'id':self_id,
            'surname_name':models.get_surname_name(self_id).split(),
            'list_objects':models.list_objects(),
            'list_topics':models.list_topics(),
            'list_types':models.list_types(),
            'open_object':open_object,
            'open_topic':open_topic,
            'open_type':open_type,
            'id_object':int(id_object),
            'id_topic':int(id_topic),
        }
        return render(request,'adminpage/object_topic_type.html',context)


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ВОПРОСЫ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
def questions(request):
    if request.method=='GET':
        id=request.GET['id']
        if models.check_session(id):
            context={
                'id':id,
                'surname_name':models.get_surname_name(id).split(),
                'list_object_topic_type':models.list_object_topic_type(),
                'list_questions':models.list_questions(),
                'sort_by_object':(0,),
                'k':1,
            }
            context['limit']=[i for i in range(1,ceil(len(context['list_questions'])/25)+1)]
            context['list_questions']=context['list_questions'][:25]
            return render(request,'adminpage/questions.html',context)
        else:
            return render(request,'403.html')
    else:
        sort_by_object='0'
        if 'add_question' in request.POST:
            self_id,k,sort_by_object=request.POST['add_question'].split('_')
            id_object,id_topic,id_type=request.POST['object_topic_type'].split('_')
            if len(request.FILES)!=0:
                file=request.FILES['file']
                models.add_some_questions(id_object,id_topic,id_type,file)
            else:
                text=request.POST['text']
                answer=request.POST['answer']
                models.add_question(id_object,id_topic,id_type,text,answer)
            return redirect(f'/admin/questions/?id={self_id}')
        elif 'update_question' in request.POST:
            id_question,self_id,k,sort_by_object=request.POST['update_question'].split('_')
            text=request.POST['question']
            answer=request.POST['answer']
            models.update_question(id_question,text,answer)
        elif 'del_question' in request.POST:
            id_question,self_id,k,sort_by_object=request.POST['del_question'].split('_')
            models.del_question(id_question)
        elif 'update_table' in request.POST:
            self_id,k,sort_by_object=request.POST['update_table'].split('_')
        elif 'copy_question' in request.POST:
            id_question,self_id,k,sort_by_object=request.POST['copy_question'].split('_')
            models.copy_question(id_question)
        elif 'sort_by_objects' in request.POST:
            self_id,k,sort_by_object=request.POST['sort_by_objects'].split('_')
            k=1
        context={
                'id':self_id,
                'surname_name':models.get_surname_name(self_id).split(),
                'list_object_topic_type':models.list_object_topic_type(),
                'list_questions':models.list_questions(int(sort_by_object[0])),
                'sort_by_object':(int(sort_by_object),),
                'k':k,
            }
        context['limit']=[str(i) for i in range(1,ceil(len(context['list_questions'])/25)+1)]
        context['list_questions']=context['list_questions'][(int(k)-1)*25:int(k)*25]
        return render(request,'adminpage/questions.html',context)

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ТЕСТЫ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
def tests(request):
    if request.method=='GET':
        id=request.GET['id']
        if models.check_session(id):
            context={
                'id':id,
                'surname_name':models.get_surname_name(id).split(),
                'list_objects':models.list_objects(),
                'list_object_topic_type':models.list_object_topic_type(),
                'list_groups':models.list_groups(),
                'list_tests':models.list_tests(),
                'list_results':models.get_tests_results(),
            }
            return render(request,'adminpage/tests.html',context)
        else:
            return render(request,'403.html')
    else:
        test=None
        list_questions=None
        if 'add_test' in request.POST:
            self_id=request.POST['add_test']
            name=request.POST['name']
            groups=request.POST.getlist('groups[]')
            id_object=request.POST['object']
            numbers=request.POST.getlist('quantity[]')
            types=request.POST.getlist('types[]')
            questions=dict(zip(types,numbers))
            rand=request.POST.get('random',False)
            models.add_test(id_object,name,questions,groups,rand)
            return redirect(f'/admin/tests/?id={self_id}')
        elif 'update_test' in request.POST:
            id,self_id=request.POST['update_test'].split('_')
            name=request.POST['name']
            groups=request.POST.getlist('groups[]')
            if 'questions[]' in request.POST:
                questions=request.POST.getlist('questions[]')
            else:
                numbers=request.POST.getlist('quantity[]')
                types=request.POST.getlist('types[]')
                questions=dict(zip(types,numbers))
            test=models.update_test(id,name,questions,groups)
        elif 'del_test' in request.POST:
            id,self_id=request.POST['del_test'].split('_')
            test=models.del_test(id)
            return redirect(f'/admin/tests/?id={self_id}')
        elif 'update_active' in request.POST:
            id,self_id,active=request.POST['update_active'].split('_')
            test=models.update_active(id,active)
        elif 'test' in request.POST:
            self_id,id=request.POST['test'].split('_')
            if id=='0':
                return redirect(f'/admin/tests/?id={self_id}')
            test=models.get_test(id)
        elif 'del_result' in request.POST:
            self_id,id=request.POST['del_result'].split('_')
            models.del_result(id)
            return redirect(f'/admin/tests/?id={self_id}')
        if test!=None and type(test[3])==list:
            list_questions=models.list_questions_on_object(test[1][0])
        context={
                'id':self_id,
                'surname_name':models.get_surname_name(self_id).split(),
                'list_objects':models.list_objects(),
                'list_object_topic_type':models.list_object_topic_type(),
                'list_results':models.get_tests_results(),
                'list_groups':models.list_groups(),
                'list_tests':models.list_tests(),
                'test':test,
                'list_questions':list_questions,
            }
        if test!=None:
            context['list_types']=context['list_object_topic_type'][test[1]]
        return render(request,'adminpage/tests.html',context)

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ЗАПИСИ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
def posts(request):
    if request.method=='GET':
        id=request.GET['id']
        if models.check_session(id):
            context={
                'id':id,
                'list_groups':models.list_groups(),
                'surname_name':models.get_surname_name(id).split(),
            }
            return render(request,'adminpage/posts.html',context)
        else:
            return render(request,'403.html')
    else:
        posts=None
        group=-1
        if 'add_post' in request.POST:
            self_id=request.POST['add_post']
            group=request.POST['group']
            name=request.POST['name']
            date=request.POST['date']
            text=request.POST['text']
            models.add_post(group,date,name,text)
            group=-1
            return redirect(f'/admin/posts/?id={self_id}')
        elif 'add_work' in request.POST:
            self_id=request.POST['add_work']
            group=request.POST['group']
            name=request.POST['name']
            date=request.POST['date']
            form=request.POST['form']
            titles=request.POST.getlist('title[]')
            texts=request.POST.getlist('text[]')
            dist_title_text=dict(zip(titles,texts))
            models.creat_work(group,date,name,form,dist_title_text)
            group=-1
            return redirect(f'/admin/posts/?id={self_id}')
        elif 'select_group' in request.POST:
            self_id,group=request.POST['select_group'].split('_')
            posts=models.get_posts(group)
        elif 'del_post' in request.POST:
            self_id,id,group=request.POST['del_post'].split('_')
            models.del_post(id)
            posts=models.get_posts(group)
        elif 'fix' in request.POST:
            self_id,id,group,val=request.POST['fix'].split('_')
            models.fix_post(id,val)
            posts=models.get_posts(group)
        elif 'access' in request.POST:
            self_id,id,group,val=request.POST['access'].split('_')
            models.access_post(id,val)
            posts=models.get_posts(group)
        context={
                'id':self_id,
                'list_groups':models.list_groups(),
                'surname_name':models.get_surname_name(self_id).split(),
                'list_posts':posts,
                'group':int(group),
            }
        return render(request,'adminpage/posts.html',context)

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~КНИГИ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
def books(request):
    if request.method=='GET':
        id=request.GET['id']
        if models.check_session(id):
            context={
                'id':id,
                'hello':('hello' in request.GET),
                'surname_name':models.get_surname_name(id).split(),
                'list_objects':models.list_objects(),
                'list_books':models.list_books(),
                'sort_by_object':(0,),
                'k':1,
            }
            context['limit']=[i for i in range(1,ceil(len(context['list_books'])/25)+1)]
            context['list_books']=context['list_books'][:25]
            return render(request,'adminpage/books.html',context)
        else:
            return render(request,'403.html')
    else:
        k=1
        sort_by_object='0'
        if 'add_book' in request.POST:
            self_id=request.POST['add_book']
            object=request.POST['object']
            name=request.POST['name']
            file=request.FILES['data']
            models.add_book(object,name,file)
            redirect(f'/admin/books/?id={self_id}')
        elif 'del_book' in request.POST:
            self_id,id,k,sort_by_object=request.POST['del_book'].split('_')
            models.del_book(id)
        elif 'update_table' in request.POST:
            self_id,k,sort_by_object=request.POST['update_table'].split('_')
        elif 'sort_by_objects' in request.POST:
            self_id,k,sort_by_object=request.POST['sort_by_objects'].split('_')
            k=1
        context={
                'id':self_id,
                'list_groups':models.list_groups(),
                'surname_name':models.get_surname_name(self_id).split(),
                'list_objects':models.list_objects(),
                'list_books':models.list_books(int(sort_by_object[0])),
                'sort_by_object':(int(sort_by_object),),
                'k':k,
            }
        context['limit']=[str(i) for i in range(1,ceil(len(context['list_books'])/25)+1)]
        context['list_books']=context['list_books'][(int(k)-1)*25:int(k)*25]
        return render(request,'adminpage/books.html',context)