from django import template

register = template.Library()

@register.filter(name='get')
def get(arr, i):
    return arr[int(i)]

@register.filter(name='plus')
def plus(string, img):
    return string+img

@register.filter(name='get_type')
def get_type(var,t):
    return str(type(var))[8:-2]==t