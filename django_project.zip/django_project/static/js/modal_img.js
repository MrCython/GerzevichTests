function modal_img(img_src){
    var modal = document.getElementById('myModal');
    var modalImg = document.getElementById("img01");
    modal.style.display = "block";
    modalImg.src = img_src;
}
function close_modal(){
    var modal = document.getElementById('myModal');
    modal.style.display = "none";
}