function select(val,btn){
    if (val!="0"){
        button = document.getElementById(btn);
        button.disabled = false;
        button.style.background = "#0071f0";
    }else{
        button = document.getElementById(btn);
        button.disabled = true;
        button.style.background = "#82b2e9";
    }
}
function add(){
    div = document.getElementById('list_content');
    btn = document.getElementsByClassName('btn');
    modals = document.getElementById('modals');
    if (btn.length==0){
        num=1;
    }else{
        let last=document.getElementsByClassName('del')[btn.length-1].value;
        num=Number(last)+1;
    }
    div.insertAdjacentHTML('beforeend',
    '<div style="padding:  2px 0 0 5px;" id="btn_'+num+'">'+
        '<div class="btn">'+
            '<scan onclick="open_modal('+num+')" id="title_'+num+'">Вариант '+num+'</scan> '+
            '<input type="hidden" name="title[]" value="Вариант '+num+'" id="title_input_'+num+'">'+
            '<button type="button" class="del" value="'+num+'" onclick="del('+num+')">✖</button>'+
            '<textarea id="text_'+num+'" style="display: none" name="text[]"></textarea>'+
        '</div>'+
    '</div>'
    )
}
function del(id){
    div = document.getElementById('btn_'+id);
    div.remove();
}
function open_modal(id){
    title = document.getElementById('title');
    new_title = document.getElementById('title_'+id);
    new_text = document.getElementById('text_'+id);
    div = document.getElementById('box_close');
    title.value = new_title.innerHTML;
    myEditor.data.set(new_text.value);
    div.innerHTML = '<span class="close" onclick="close_modal('+id+')" id="close_'+id+'">&times;</span>';
    modal = document.getElementById('modal');
    modal.style.display = "block";
}
function close_modal(id){
    title = document.getElementById('title');
    new_title = document.getElementById('title_'+id);
    new_text = document.getElementById('text_'+id);
    input = document.getElementById('title_input_'+id);
    new_title.innerHTML = title.value;
    input.value = title.value;
    new_text.value = myEditor.getData();
    modal = document.getElementById('modal');
    modal.style.display = "none";
}
function open_work(id){
    title = document.getElementById('title_'+id);
    content = document.getElementById('content_'+id);
    header = document.getElementById('modal-header');
    body = document.getElementById('modal-body');
    div = document.getElementById('My_box_close');
    div.innerHTML = '<span class="close" onclick="close_work()">&times;</span>';
    header.innerHTML = title.innerHTML;
    body.innerHTML = content.innerHTML;
    modal = document.getElementById('My_modal');
    modal.style.display = "block";
}
function close_work(){
    modal = document.getElementById('My_modal');
    modal.style.display = "none";
}