function select_object(class_name,id){
    let len_table = document.getElementsByClassName(class_name).length;
    for (let i=0;i<len_table;i++){
        document.getElementsByClassName(class_name)[i].style.display = "none";
    }
    table = document.getElementById(class_name+'_'+id);
    table.style.display = "";
}