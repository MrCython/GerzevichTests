function select(object_topic_type,name,k){
    elem = document.getElementById('value_'+k);
    elem.value = object_topic_type;
    summary = document.getElementById('field_'+k);
    summary.innerHTML=name;
    details = document.getElementById(k);
    details.open = false;
    if (k=='0'){
        button = document.getElementById('add_question');
        button.disabled = false;
        button.style.background = "#0071f0";
    }
}
function search(){
    table = document.getElementById("myTable");
    tr = table.getElementsByTagName("tr");
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    for (i = 1; i < tr.length; i++) {
        text = document.getElementsByClassName("id")[i-1].innerHTML;
        if (text.toUpperCase().indexOf(filter) > -1) {
            tr[i].style.display = "";
        } else {
            tr[i].style.display = "none";
        }
    }
}
function open_modal(id){
    title = document.getElementById('title');
    new_text = document.getElementById('content_'+id);
    div = document.getElementById('box_close');
    title.innerHTML = 'Вопрос №'+id;
    myEditor.data.set(new_text.innerHTML);
    div.innerHTML = '<span class="close" onclick="close_modal('+id+')" id="close_'+id+'">&times;</span>';
    modal = document.getElementById('modal');
    modal.style.display = "block";
}
function close_modal(id){
    title = document.getElementById('title');
    new_text = document.getElementById('content_'+id);
    text_data = document.getElementById('text_'+id);
    title.innerHTML = '';
    new_text.innerHTML = myEditor.getData();
    text_data.value = myEditor.getData();
    modal = document.getElementById('modal');
    modal.style.display = "none";
}