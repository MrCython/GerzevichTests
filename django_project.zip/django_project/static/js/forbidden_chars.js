function check_chars(k) {
    message = document.getElementById('attention_'+k);
    message.style.display = "none";
    var chars='!"#$%&\'()*+,-./:;<=>?@[\\]^_{|}~';
    textarea = document.getElementById('check_'+k).value;
    button = document.getElementById('btn_'+k);
    for (let i=0;i<chars.length;i++){
        if (textarea.indexOf(chars[i]) > -1){
            button.disabled = true;
            message.style.display = "";
            button.style.background = "#82b2e9";
            break;
        }
        else{
            button.disabled = false;
            button.style.background = "#0071f0";
        }
    }
}