function show(val){
    questions = document.getElementsByClassName('question')
    btn = document.getElementsByClassName('btn')
    for (let i=0;i<questions.length;i++){
        questions[i].style.display = "none";
        if (i+1==val){
            btn[i].style.background = "gray";
        }else{
            btn_save=document.getElementsByClassName('btn_save');
            if (btn_save[i].innerHTML=="Сохранить"){
                btn[i].style.background = "cadetblue";
            }else{
                btn[i].style.background = "#337ab7";
            }
        }
    }
    question = document.getElementById(val);
    question.style.display = "";
}
function save(k){
    btn_num = document.getElementsByClassName('btn')[k-1];
    btn = document.getElementsByClassName('btn_save')[k-1];
    input = document.getElementsByClassName('answer')[k-1];
    if (btn.innerHTML=="Сохранить"){
        input.disabled=true;
        btn.style.background = "#82b2e9";
        btn.innerHTML="Cохранено";
        btn_num.style.background = "#337ab7";
    }else{
        input.disabled=false;
        btn.style.background = "#0071f0";
        btn.innerHTML="Сохранить";
        btn_num.style.background = "cadetblue";
    }
}
function get_result(){
    btn = document.getElementsByClassName('btn_save');
    input = document.getElementsByClassName('answer');
    for (let i=0;i<input.length;i++){
        input[i].disabled=false;
        if (btn[i].innerHTML=="Сохранить"){
            input[i].value='Nоne';
        }
    }
}