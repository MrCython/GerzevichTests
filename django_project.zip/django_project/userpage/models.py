from random import *
import csv,os,sqlite3,re,time,os.path
from django.conf import settings

class models:
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ПРОВЕРКА ЛОГИНА И ПАРОЛЯ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def check_log_pass(login,password):
        conn = sqlite3.connect(os.path.join(settings.BASE_DIR, 'db.sqlite3'))
        cur = conn.cursor()
        cur.execute('DELETE FROM SESSION_USERS WHERE kill_time<?',(int(time.time()),))
        id=cur.execute('SELECT id FROM  USERS WHERE login=? AND password=?',(login,password)).fetchone()
        if type(id)!=tuple:
            answer=False
        else:
            offline=cur.execute('SELECT id FROM SESSION_USERS WHERE id=?',(id[0],)).fetchone()
            if type(offline)!=tuple:
                cur.execute('INSERT INTO SESSION_USERS VALUES(?,?)',(id[0],int(time.time())+3600*2))
                answer=id[0]
            else:
                answer=False
        conn.commit()
        return answer
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ПРОВЕРКА СЕССИИ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def check_session(id):
        conn = sqlite3.connect(os.path.join(settings.BASE_DIR, 'db.sqlite3'))
        cur = conn.cursor()
        cur.execute('DELETE FROM SESSION_USERS WHERE kill_time<?',(int(time.time()),)) #Удаление истекших сессий
        online=cur.execute('SELECT id FROM SESSION_USERS WHERE id=?',(id,)).fetchone()
        conn.commit()
        answer=(type(online)==tuple)
        return answer
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ВЫХОД~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def quit(id,self_id=0):
        conn = sqlite3.connect(os.path.join(settings.BASE_DIR, 'db.sqlite3'))
        cur = conn.cursor()
        cur.execute('DELETE FROM SESSION_USERS WHERE id=?',(id,))
        conn.commit()
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ПОЛУЧЕНИЕ ФАМИЛИИ, ИМЕНИ ПО ID~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def get_surname_name(id):
        if id==None:
            return 'Неизвестный пользователь'
        conn = sqlite3.connect(os.path.join(settings.BASE_DIR, 'db.sqlite3'))
        cur = conn.cursor()
        surname_name=cur.execute('SELECT surname_name FROM USERS WHERE id=?',(id,)).fetchone()
        conn.commit()
        return surname_name[0]
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~СПИСОК ГРУПП~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def list_groups(id):
        conn = sqlite3.connect(os.path.join(settings.BASE_DIR, 'db.sqlite3'))
        cur = conn.cursor()
        if id==None:
            groups=cur.execute('SELECT id,name,avatar FROM GROUPS').fetchall()
        else:   
            surname_name=cur.execute('SELECT surname_name FROM USERS WHERE id=?',(id,)).fetchone()[0]
            groups=cur.execute('SELECT id,name,avatar FROM groups WHERE users LIKE ?',(f'%{surname_name}%',)).fetchall()
        conn.commit()
        return groups
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~НАЗВАНИЕ ГРУППЫ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def get_name_group(id):
        conn = sqlite3.connect(os.path.join(settings.BASE_DIR, 'db.sqlite3'))
        cur = conn.cursor()
        group=cur.execute('SELECT id,name FROM GROUPS WHERE id=?',(id,)).fetchone()
        conn.commit()
        return group
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ЗАПИСИ ГРУППЫ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def get_posts(id,id_user=None):
        conn = sqlite3.connect(os.path.join(settings.BASE_DIR, 'db.sqlite3'))
        cur = conn.cursor()
        if id_user==None:
            posts=cur.execute('SELECT date,name,text,fix FROM POSTS WHERE id_group=? AND access=0 ORDER BY fix,date DESC',(id,)).fetchall()
        else:
            posts=cur.execute('SELECT date,name,text,fix FROM POSTS WHERE id_group=? ORDER BY fix,date DESC',(id,)).fetchall()
        conn.commit()
        return posts
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~СПИСОК ТЕСТОВ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~# 
    def list_tests(id):
        conn = sqlite3.connect(os.path.join(settings.BASE_DIR, 'db.sqlite3'))
        cur = conn.cursor()
        surname_name=cur.execute('SELECT surname_name FROM USERS WHERE id=?',(id,)).fetchone()[0]
        groups=cur.execute('SELECT id FROM groups WHERE users LIKE ?',(f'%{surname_name}%',)).fetchall()
        groups={str(i[0]) for i in groups}|{'*'}
        objects=cur.execute('SELECT name,id FROM OBJECTS').fetchall()
        result={}
        for object in objects:
            tests=cur.execute('SELECT * FROM TESTS WHERE id_object=? AND active=1',(object[1],)).fetchall()
            tests=[i for i in tests if not(groups.isdisjoint(set(i[4].split(', '))))]
            result[object]=tests
        conn.commit()
        return result
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ПОДБОР ВОПРОСОВ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def get_questions(id):
        conn = sqlite3.connect(os.path.join(settings.BASE_DIR, 'db.sqlite3'))
        cur = conn.cursor()
        types=cur.execute('SELECT questions FROM TESTS WHERE id=?',(id,)).fetchone()[0]
        if ':' in types:
            types=dict([i.split(': ') for i in types.split(', ')[1:-1]])
            result=[]
            for type in types:
                questions=cur.execute('SELECT id,question FROM QUESTIONS WHERE id_type=?',(int(type),)).fetchall()
                result+=sample(questions,int(types[type]))
        else:
            types=types.split(', ')[1:-1]
            result=[]
            for i in range(len(types)):
                result.append(cur.execute('SELECT id,question FROM QUESTIONS WHERE id=?',(types[i],)).fetchone())
        conn.commit()
        shuffle(result)
        result=[[i+1]+list(result[i]) for i in range(len(result))]
        return result
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ПОДБОР ВОПРОСОВ ДЛЯ ПРЕДОСМОТРА ТЕСТА~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def get_questions_for_show(id):
        conn = sqlite3.connect(os.path.join(settings.BASE_DIR, 'db.sqlite3'))
        cur = conn.cursor()
        types=cur.execute('SELECT questions FROM TESTS WHERE id=?',(id,)).fetchone()[0]
        if ':' in types:
            types=dict([i.split(': ') for i in types.split(', ')[1:-1]])
            result=[]
            for type in types:
                questions=cur.execute('SELECT id,question FROM QUESTIONS WHERE id_type=?',(int(type),)).fetchmany(int(types[type]))
                result+=questions
        else:
            types=types.split(', ')[1:-1]
            result=[]
            for i in range(len(types)):
                result.append(cur.execute('SELECT id,question FROM QUESTIONS WHERE id=?',(types[i],)).fetchone())
        conn.commit()
        return result
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ИНфОРМАЦИЯ О ТЕСТАХ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def get_test(id):
        conn = sqlite3.connect(os.path.join(settings.BASE_DIR, 'db.sqlite3'))
        cur = conn.cursor()
        test=cur.execute('SELECT id,name FROM TESTS WHERE id=?',(id,)).fetchone()
        conn.commit()
        return test
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~РЕЗУЛЬТАТ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def get_result(test,answers,time_test,id_user):
        all_answers,right_answers=0,0
        conn = sqlite3.connect(os.path.join(settings.BASE_DIR, 'db.sqlite3'))
        cur = conn.cursor()
        surname_name=cur.execute('SELECT surname_name FROM USERS WHERE id=?',(id_user,)).fetchone()[0]
        name_test=cur.execute('SELECT name FROM TESTS WHERE id=?',(test,)).fetchone()[0]
        time_test=time.strftime('%X',time.gmtime(int(time_test)))
        data=f'<tr><td>{surname_name}</td><td>{time.strftime("%d/%m/%y")}<br>{time_test}</td>'
        all_questions=cur.execute('SELECT questions FROM TESTS WHERE id=?',(test,)).fetchone()[0]
        if ':' in all_questions:
            all_questions=sum([int(i.split(': ')[1]) for i in all_questions.split(', ')[1:-1]])
        else:
            all_questions=len(all_questions.split(', ')[1:-1])
        for id,ans in sorted(answers.items(),key=lambda x:int(x[0])):
            right_answer=cur.execute('SELECT answer FROM QUESTIONS WHERE id=?',(id,)).fetchone()[0]
            data+=f'<td class={"true" if ans.strip()==right_answer.strip() else "false"}>id: {id}, отв:{right_answer}<br><h4>{ans if ans!="Nоne" else " "}</h4></td>'
            if ans.strip()==right_answer.strip():
                right_answers+=1
            if ans.strip()!='Nоne':
                all_answers+=1
        data+=f'<td>Всего: {all_answers}</td></tr>\n'
        cur.execute('UPDATE RESULTS SET content=content||? WHERE id_test=?',(data,test))
        conn.commit()
        result=f'{all_questions},{all_answers},{right_answers},{round((right_answers/(all_answers if all_answers!=0 else 1))*100,2)},{time_test}'
        return result
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ПОЛЬЗОВАТЕЛИ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def get_users(group):
        conn = sqlite3.connect(os.path.join(settings.BASE_DIR, 'db.sqlite3'))
        cur = conn.cursor()
        users_from_group=cur.execute('SELECT users FROM GROUPS WHERE id=?',(group,)).fetchone()[0]
        users=cur.execute('SELECT surname_name,login,password FROM USERS WHERE ? LIKE "%"||surname_name||"%"',(users_from_group,)).fetchall()
        conn.commit()
        return users
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~РЕЗУЛЬТАТ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def get_content(test):
        conn = sqlite3.connect(os.path.join(settings.BASE_DIR, 'db.sqlite3'))
        cur = conn.cursor()
        result=cur.execute('SELECT * FROM RESULTS WHERE id_test=?',(test,)).fetchone()
        conn.commit()
        return result
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ГРУППЫ ДЛЯ СЕЛЕКЦИИ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def groups_for_selector():
        conn = sqlite3.connect(os.path.join(settings.BASE_DIR, 'db.sqlite3'))
        cur = conn.cursor()
        groups=cur.execute('SELECT name,users FROM GROUPS').fetchall()
        conn.commit()
        return groups

class helper:
    pass