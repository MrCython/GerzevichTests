from adminpage.views import groups
from os import name
from django.shortcuts import *
from django.utils.regex_helper import Group
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponse,JsonResponse
from .models import models
from math import *
import time

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ВХОД~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
def enter(request):
    if request.method=='GET':
        return render(request,'userpage/enter.html',context={'answer':'Введите логин и пароль'})
    else:
        login=request.POST['login']
        password=request.POST['password']
        access=models.check_log_pass(login,password)
        if access:
            return redirect(f'/?id={access}&hello')
        else:
            return render(request,'userpage/enter.html',context={'answer':'Неверный логин или пароль или пользователь уже в сети'})

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~НОВОСТИ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
def select(request):
    if request.method=='GET':
        id=request.GET.get('id')
        context={
            'id':id,
            'hello':('hello' in request.GET),
            'surname_name':models.get_surname_name(id).split(),
            'list_groups':models.list_groups(id),
        }
        if id==None:
            return render(request,'userpage/select.html',context)
        elif models.check_session(id):
            return render(request,'userpage/select.html',context)
        else:
            return render(request,'403.html')
    else:
        if 'quit' in request.POST:
            id=request.POST['quit']
            models.quit(id)
            return redirect('/')

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ЗАПИСИ ГРУППЫ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
def klass(request):
    if request.method=='GET':
        id=request.GET.get('id')
        group=request.GET['klass']
        context={
            'id':id,
            'surname_name':models.get_surname_name(id).split(),
            'list_posts':models.get_posts(group,id),
            'group':models.get_name_group(group),
        }
        if id==None:
            return render(request,'userpage/klass.html',context)
        elif models.check_session(id):
            return render(request,'userpage/klass.html',context)
        else:
            return render(request,'403.html')
    else:
        pass

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ВЫБОР ТЕСТА~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
def tests(request):
    if request.method=='GET':
        id=request.GET.get('id')
        if models.check_session(id):
            context={
                'id':id,
                'surname_name':models.get_surname_name(id).split(),
                'list_tests':models.list_tests(id),
            }
            return render(request,'userpage/tests.html',context)
        else:
            return render(request,'403.html')
    else:
        pass

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ТЕСТ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
def test(request):
    if request.method=='GET':
        id=request.GET['id']
        test=request.GET['test']
        if models.check_session(id):
            context={
                'id':id,
                'surname_name':models.get_surname_name(id).split(),
                'questions':models.get_questions(test),
                'test':models.get_test(test),
                'time_start':int(time.time()),
            }
            return render(request,'userpage/test.html',context)
        else:
            return render(request,'403.html')
    else:
        if 'end_test' in request.POST:
            self_id,test=request.POST['end_test'].split('_')
            questions=request.POST.getlist('ids[]')
            answers=request.POST.getlist('answers[]')
            dict_answers=dict(zip(questions,answers))
            time_test=int(time.time())-int(request.POST['time'])
            result=models.get_result(test,dict_answers,time_test,self_id)
        context={
                'id':self_id,
                'surname_name':models.get_surname_name(self_id).split(),
                'test':(0,'Результат'),
                'result':result,
            }
        return render(request,'userpage/test.html',context)

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ПРОСМОТР ПОЛЬЗОВАТЕЛЕЙ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
def get_users(request):
    if request.method=='GET':
        group=request.GET['group']
        context={
            'group':models.get_name_group(group),
            'content':models.get_users(group),
        }
        return render(request,'speciall/users.html',context)
    else:
        pass

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ПРОСМОТР ТЕСТА~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
def get_test(request):
    if request.method=='GET':
        id=request.GET['id']
        context={
            'test':models.get_test(id),
            'content':sorted(models.get_questions_for_show(id),key=lambda x:x[0]),
        }
        return render(request,'speciall/test.html',context)
    else:
        pass

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ПРОСМОТР РЕЗУЛЬТАТА~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
def get_result(request):
    if request.method=='GET':
        test=request.GET['test']
        context={
            'list_groups':models.groups_for_selector(),
            'content':models.get_content(test),
        }
        return render(request,'speciall/result.html',context)
    else:
        pass