from django.urls import path
from . import views 
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('login/',views.enter),
    path('',views.select),
    path('klass/',views.klass),
    path('tests/',views.tests),
    path('test/',views.test),
    path('get_users/',views.get_users),
    path('get_test/',views.get_test),
    path('get_result/',views.get_result),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)