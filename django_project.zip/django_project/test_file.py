import sqlite3,os
conn = sqlite3.connect('db.sqlite3')
cur = conn.cursor()
users=""
print(cur.execute('SELECT id FROM USERS WHERE ? LIKE "%"||surname_name||"%"',(users,)).fetchall())
conn.commit()