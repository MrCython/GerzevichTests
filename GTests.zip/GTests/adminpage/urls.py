from functools import partial
from os import name
from django.urls import path
from . import views 

urlpatterns = [
    path('',views.enter),
    path('news/',views.select),
    path('users/',views.users),
    path('groups/',views.groups),
    path('categories/',views.categories),
    path('questions/',views.questions),
    path('tests/',views.tests),
    path('posts/',views.posts),
]