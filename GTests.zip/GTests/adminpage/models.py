from random import *
import csv,os,sqlite3,re,time
from django.http import request


class models:
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ПРОВЕРКА ЛОГИНА И ПАРОЛЯ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def check_log_pass(login,password):
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        cur.execute('DELETE FROM SESSION_USERS WHERE kill_time<?',(int(time.time()),))
        id=cur.execute('SELECT id FROM  USERS WHERE login=? AND password=? AND rank IN("Администратор","Учитель")',(login,password)).fetchone()
        if type(id)!=tuple:
            answer=False
        else:
            offline=cur.execute('SELECT id FROM SESSION_ADMIN WHERE id=?',(id[0],)).fetchone()
            if type(offline)!=tuple:
                cur.execute('INSERT INTO SESSION_ADMIN VALUES(?,?)',(id[0],int(time.time())+3600*2))
                answer=id[0]
            else:
                answer=False
        conn.commit()
        return answer
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ПРОВЕРКА СЕССИИ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def check_session(id):
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        cur.execute('DELETE FROM SESSION_ADMIN WHERE kill_time<?',(int(time.time()),)) #Удаление истекших сессий
        online=cur.execute('SELECT id FROM SESSION_ADMIN WHERE id=?',(id,)).fetchone()
        conn.commit()
        answer=(type(online)==tuple)
        return answer
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~УДАЛЕНИЕ СЕССИИ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def del_session(id):
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        cur.execute('DELETE FROM SESSION_ADMIN WHERE id=?',(id,))
        conn.commit()
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ПОЛУЧЕНИЕ ФАМИЛИИ, ИМЕНИ ПО ID~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def get_surname_name(id):
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        surname_name=cur.execute('SELECT surname_name FROM USERS WHERE id=?',(id,)).fetchone()
        conn.commit()
        return surname_name[0]
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~СПИСОК ПОЛЬЗОВАТЕЛЕЙ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def list_users():
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        users=cur.execute('SELECT * FROM USERS').fetchall()
        conn.commit()
        return users
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~УДАЛЕНИЕ ПОЛЬЗОВАТЕЛЯ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def del_user(id):
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        cur.execute('DELETE FROM SESSION_ADMIN WHERE id=?',(id,))
        cur.execute('DELETE FROM USERS WHERE id=?',(id,))
        conn.commit()
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ОБНОВЛЕНИЕ ДАННЫХ ПОЛЬЗОВАТЕЛЯ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def update_user(id,surname_name,login,password,rank):
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        cur.execute('UPDATE USERS SET surname_name=?, login=?, password=?, rank=? WHERE id=?',(surname_name,login,password,rank,id))
        conn.commit()
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ДОБАВЛЕНИЕ ПОЛЬЗОВАТЕЛЯ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def add_user(surname_name,rank):
        for user in surname_name:
            if len(user.split())!=2:
                continue
            id=helper.new_id('USERS')
            login=helper.generator_login(*user.split())
            password=helper.generator_password(rank=='Учитель')
            conn = sqlite3.connect('db.sqlite3')
            cur = conn.cursor()
            cur.execute('INSERT INTO USERS VALUES(?,?,?,?,?)',(id,user,login,password,rank))
            conn.commit()
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~СОЗДАНИЕ ГРУППЫ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def creat_group(name,img,creator,users):
        id=helper.new_id('GROUPS')
        if img!=None:
            namefile=f'{str(id)}.{img.name.split(".")[1]}'
            with open(os.path.join('static/groups_avatars',namefile),'wb') as file:
                file.write(img.read())
        else:
            namefile='no_pictures.jpg'
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        cur.execute('INSERT INTO GROUPS VALUES(?,?,?,?,?)',(id,name,creator,users,namefile))
        conn.commit()
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~СПИСОК ГРУПП~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def list_groups():
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        groups=cur.execute('SELECT * FROM GROUPS').fetchall()
        conn.commit()
        return groups
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ИЗМЕНЕНИЕ ГРУППЫ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def update_group(id,name,img,del_avatar,creator,users):
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        namefile=cur.execute('SELECT avatar FROM GROUPS WHERE id=?',(id,)).fetchone()[0]
        if del_avatar:
            os.remove('static/groups_avatars/'+namefile)
            namefile='no_pictures.jpg'
        if img!=None:
            namefile=f'{str(id)}.{img.name.split(".")[1]}'
            with open(os.path.join('static/groups_avatars',namefile),'wb') as file:
                file.write(img.read())
        cur.execute('UPDATE GROUPS SET name=?,creator=?,users=?,avatar=? WHERE id=?',(name,creator,users,namefile,id))
        conn.commit()
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~УДАЛЕНИЕ ГРУППЫ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def delete_group(id):
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        namefile=cur.execute('SELECT avatar FROM GROUPS WHERE id=?',(id,)).fetchone()[0]
        if namefile!='no_pictures.jpg':
            os.remove('static/groups_avatars/'+namefile)
        cur.execute('DELETE FROM GROUPS WHERE id=?',(id,))
        cur.execute('DELETE FROM POSTS WHERE id_group=?',(id,))
        conn.commit()
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~СПИСОК ПРЕДМЕТОВ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def list_objects():
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        objects=cur.execute('SELECT * FROM OBJECTS').fetchall()
        conn.commit()
        return objects
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ДОБАВИТЬ ПРЕДМЕТ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def add_object(name):
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        id=helper.new_id('OBJECTS')
        cur.execute('INSERT INTO OBJECTS VALUES(?,?,0)',(id,name))
        conn.commit()
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~УДАЛИТЬ ПРЕДМЕТ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def del_object(id):
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        cur.execute('DELETE FROM OBJECTS WHERE id=?',(id,))
        cur.execute('DELETE FROM TOPICS WHERE id_object=?',(id,))
        cur.execute('DELETE FROM TYPES WHERE id_object=?',(id,))
        cur.execute('DELETE FROM QUESTIONS WHERE id_object=?',(id,))
        conn.commit()
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~СПИСОК ТЕМ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def list_topics():
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        objects=cur.execute('SELECT id,name FROM OBJECTS').fetchall()
        result={}
        for i in objects:
            topics=cur.execute('SELECT * FROM TOPICS WHERE id_object=?',(i[0],)).fetchall()
            result[i]=topics
        conn.commit()
        return result
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~СОЗДАНИЕ ТЕМ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def add_topic(id_object,name):
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        id=helper.new_id('TOPICS')
        cur.execute('INSERT INTO TOPICS VALUES(?,?,?,0)',(id,id_object,name))
        cur.execute('UPDATE OBJECTS SET lot_topics=lot_topics+1 WHERE id=?',(id_object,))
        conn.commit()
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~УДАЛЕНИЕ ТЕМ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def del_topic(id):
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        id_object=cur.execute('SELECT id_object FROM TOPICS WHERE id=?',(id,)).fetchone()[0]
        cur.execute('DELETE FROM TOPICS WHERE id=?',(id,))
        cur.execute('DELETE FROM TYPES WHERE id_topic=?',(id,))
        cur.execute('UPDATE OBJECTS SET lot_topics=lot_topics-1 WHERE id=?',(id_object,))
        cur.execute('DELETE FROM QUESTIONS WHERE id_topic=?',(id,))
        conn.commit()
        return id_object
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~СПИСОК ТИПОВ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def list_types():
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        objects=cur.execute('SELECT id,name FROM OBJECTS').fetchall()
        result={}
        for object in objects:
            topics=cur.execute('SELECT id,name FROM TOPICS WHERE id_object=?',(object[0],)).fetchall()
            for topic in topics:
                result[topic]=cur.execute('SELECT * FROM TYPES WHERE id_topic=?',(topic[0],)).fetchall()
        conn.commit()
        return result
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ДОБАВЛЕНИЕ ТИПОВ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def add_type(id_topic,name):
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        id=helper.new_id('TYPES')
        id_object=cur.execute('SELECT id_object FROM TOPICS WHERE id=?',(id_topic,)).fetchone()[0]
        cur.execute('INSERT INTO TYPES VALUES(?,?,?,?,0)',(id,id_object,id_topic,name))
        cur.execute('UPDATE TOPICS SET lot_types=lot_types+1 WHERE id=?',(id_topic,))
        conn.commit()
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~УДАЛЕНИЕ ТИПОВ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def del_type(id):
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        id_topic=cur.execute('SELECT id_topic FROM TYPES WHERE id=?',(id,)).fetchone()[0]
        cur.execute('DELETE FROM TYPES WHERE id=?',(id,))
        cur.execute('DELETE FROM QUESTIONS WHERE id_type=?',(id,))
        cur.execute('UPDATE TOPICS SET lot_types=lot_types-1 WHERE id=?',(id_topic,))
        conn.commit()
        return id_topic
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~СЛОВАРЬ ПРЕДМЕТЫ, ТЕМЫ, ТИПЫ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#    
    def list_object_topic_type():
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        objects=cur.execute('SELECT id,name FROM OBJECTS').fetchall()
        result={}
        for object in objects:
            topics=cur.execute('SELECT id,name FROM TOPICS WHERE id_object=?',(object[0],)).fetchall()
            types={}
            for topic in topics:
                types[topic]=cur.execute('SELECT id,name,let_questions FROM TYPES WHERE id_topic=?',(topic[0],)).fetchall()
            result[object]=types
        conn.commit()
        return result
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ДОБАВЛЕНИЕ ВОПРОСА~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~# 
    def add_question(id_object,id_topic,id_type,text,answer):
        id=helper.new_id('QUESTIONS')
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        name_type=cur.execute('SELECT name FROM TYPES WHERE id=?',(id_type,)).fetchone()[0]
        cur.execute('INSERT INTO QUESTIONS VALUES(?,?,?,?,?,?,?)',(id,id_object,id_topic,id_type,text,answer,name_type))
        cur.execute('UPDATE TYPES SET let_questions=let_questions+1 WHERE id=?',(id_type,))
        conn.commit()
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~СПИСОК ВОПРОСОВ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~# 
    def list_questions():
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        list_questions=cur.execute('SELECT * FROM QUESTIONS').fetchall()
        conn.commit()
        return list_questions
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ИЗМЕНЕНИЕ ВОПРОСА~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~# 
    def update_question(id_question,id_object,id_topic,id_type,answer):
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        name_type=cur.execute('SELECT name FROM TYPES WHERE id=?',(id_type,)).fetchone()[0]
        cur.execute('UPDATE QUESTIONS SET id_object=?,id_topic=?,id_type=?,answer=?,name_type=? WHERE id=?',(id_object,id_topic,id_type,answer,name_type,id_question))
        conn.commit()
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~УДАЛЕНИЕ ВОПРОСА~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~# 
    def del_question(id_question):
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        id_type=cur.execute('SELECT id_type FROM QUESTIONS WHERE id=?',(id_question,)).fetchone()[0]
        max_val=cur.execute('SELECT let_questions FROM TYPES WHERE id=?',(id_type,)).fetchone()[0]
        cur.execute('DELETE FROM QUESTIONS WHERE id=?',(id_question,))
        tests=cur.execute('SELECT id,questions FROM TESTS WHERE questions LIKE ?',(f'% {id_type}: {max_val},%',)).fetchall()
        for test in tests:
            questions=test[1]
            if max_val-1>0:
                questions=questions.replace(f' {id_type}: {max_val},',f' {id_type}: {max_val-1},')
            else:
                questions=questions.replace(f' {id_type}: {max_val},','')
            cur.execute('UPDATE TESTS SET questions=? WHERE id=?',(questions,test[0]))
        cur.execute('UPDATE TYPES SET let_questions=let_questions-1 WHERE id=?',(id_type,))
        conn.commit()
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~СОЗДАНИЕ ТЕСТА~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~# 
    def add_test(id_object,name,questions,groups):
        id=helper.new_id('TESTS')
        questions=', '+str(questions)[1:-1].replace('\'','')+', '
        groups=str(groups)[1:-1].replace('\'','') if '*' not in groups else '*'
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        cur.execute('INSERT INTO TESTS VALUES(?,?,?,?,?,?,?)',(id,id_object,name,questions,groups,0,0))
        conn.commit()
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~СПИСОК ТЕСТОВ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~# 
    def list_tests():
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        objects=cur.execute('SELECT name,id FROM OBJECTS').fetchall()
        result={}
        for object in objects:
            tests=cur.execute('SELECT * FROM TESTS WHERE id_object=?',(object[1],)).fetchall()
            result[object]=tests
        conn.commit()
        return result
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ИНФОРМАЦИЯ О ТЕСТЕ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~# 
    def get_test(id):
        if id=='0':return None
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        test=list(cur.execute('SELECT * FROM TESTS WHERE id=?',(id,)).fetchone())
        name_object=cur.execute('SELECT name FROM OBJECTS WHERE id=?',(test[1],)).fetchone()[0]
        test[1]=(test[1],name_object)
        test[4]=test[4].split(', ')
        if '*' not in test[4]:
            test[4]=list(map(int,test[4]))
        test[3]=dict([list(map(int,i.split(': '))) for i in test[3].split(', ')[1:-1]])
        conn.commit()
        return test
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ИЗМЕНЕНИЕ ТЕСТА~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~# 
    def update_test(id,name,questions,groups):
        questions=', '+str(questions)[1:-1].replace('\'','')+', '
        groups=str(groups)[1:-1].replace('\'','') if '*' not in groups else '*'
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        cur.execute('UPDATE TESTS SET name=?,questions=?,groups=? WHERE id=?',(name,questions,groups,id))
        conn.commit()
        return models.get_test(id)
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~УДАЛЕНИЕ ТЕСТА~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~# 
    def del_test(id):
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        cur.execute('DELETE FROM TESTS WHERE id=?',(id,))
        conn.commit()
        if os.path.isfile(os.path.join('static/results',f'{id}.csv')):
            os.remove(f'static/results/{id}.csv')
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~АКТИВАЦИЯ/ДЕАКТИВАЦИЯ ТЕСТА~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def update_active(id,active):
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        cur.execute('UPDATE TESTS SET active=? WHERE id=?',(active,id))
        conn.commit()
        return models.get_test(id)
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ЗАПИСИ ГРУППЫ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def get_posts(id):
        if id=='0':return None
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        posts=cur.execute('SELECT * FROM POSTS WHERE id_group=? ORDER BY fix,date DESC',(id,)).fetchall()
        conn.commit()
        return posts
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ДОБАВИТЬ ЗАПИСЬ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def add_post(group,date,name,text):
        id=helper.new_id('POSTS')
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        cur.execute('INSERT INTO POSTS VALUES(?,?,?,?,?,1)',(id,group,date,name,text))
        conn.commit()
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~УДАЛИТЬ ЗАПИСЬ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def del_post(id):
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        cur.execute('DELETE FROM POSTS WHERE id=?',(id,))
        conn.commit()
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ЗАКРЕПЛЕНИЕ ЗАПИСЬ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def fix_post(id,val):
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        cur.execute('UPDATE POSTS SET fix=? WHERE id=?',(val,id))
        conn.commit()
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~СПИСОК РЕЗУЛЬТАТОВ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def get_tests_results():
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        results=cur.execute('SELECT id,name FROM TESTS WHERE result=1').fetchall()
        conn.commit()
        return results
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~УДВЛЕНИЕ РЕЗУЛЬТАТОВ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def del_result(id):
        if os.path.isfile(os.path.join('static/results',f'{id}.csv')):
            os.remove(f'static/results/{id}.csv')
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        cur.execute('UPDATE TESTS SET result=0 WHERE id=?',(id,))
        conn.commit()
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ДОБАВИТЬ ИНДИВИДУАЛЬНУЮ РАБОТУ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def creat_work(group,date,name,form,dist_title_text):
        result=f'<div class="form" onclick="document.location.href = \'{form}\';">Форма для ответов</div>\r\n'
        result+='<div class="list">\r\n'
        id=helper.new_id('POSTS')
        index=1
        for title,text in dist_title_text.items():
            id_elem=f'{id}_{index}'
            elem='  <div class="elem">\r\n'
            elem+=f'    <div class="title" id="title_{id_elem}" onclick="open_work(\'{id_elem}\')">{title}</div>\r\n'
            elem+=f'    <div class="content" id="content_{id_elem}" style="display: none;">{text}</div>\r\n'
            elem+='  </div>\r\n'
            result+=elem
            index+=1
        result+='</div>'
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        cur.execute('INSERT INTO POSTS VALUES(?,?,?,?,?,1)',(id,group,date,name,result))
        conn.commit()



class helper:
    def new_id(table):
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        id=cur.execute(f"SELECT id FROM {table} ORDER BY id DESC").fetchmany(1)
        if id==[]:
            id=0
        else:
            id=int(id[0][0])
        id+=1
        conn.commit()
        return id
    def generator_password(hard=False):
        chars_easy='123456789'
        chars_hard= '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!#$%&*+-=?@^_'
        if hard:
            password=''.join([choice(chars_hard) for _ in range(10)])
        else:
            password=''.join([choice(chars_easy) for _ in range(5)])
        return password
    def generator_login(surname,name):
        chars={'а':'a','б':'b','в':'v','г':'g','д':'d','е':'e','ё':'e',
        'ж':'zh','з':'z','и':'i','й':'i','к':'k','л':'l','м':'m','н':'n',
        'о':'o','п':'p','р':'r','с':'s','т':'t','у':'u','ф':'f','х':'h',
        'ц':'c','ч':'ch','ш':'sh','щ':'scz','ъ':'','ы':'y','ь':'','э':'e',
        'ю':'u','я':'ya', 'А':'A','Б':'B','В':'V','Г':'G','Д':'D','Е':'E','Ё':'E',
        'Ж':'ZH','З':'Z','И':'I','Й':'I','К':'K','Л':'L','М':'M','Н':'N',
        'О':'O','П':'P','Р':'R','С':'S','Т':'T','У':'U','Ф':'F','Х':'H',
        'Ц':'C','Ч':'CH','Ш':'SH','Щ':'SCH','Ъ':'','Ы':'y','Ь':'','Э':'E',
        'Ю':'U','Я':'YA'}
        login=''
        for i in surname:
            login+=chars[i] if i in chars else i
        for i in name:
            login+=chars[i] if i in chars else i
            conn = sqlite3.connect('db.sqlite3')
            cur = conn.cursor()
            logins=cur.execute(f'SELECT login FROM USERS').fetchall()
            conn.commit()
            if (login,) not in logins:
                break
        return login