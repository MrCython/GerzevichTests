import sqlite3
conn = sqlite3.connect('db.sqlite3')
cur = conn.cursor()
users=cur.execute('SELECT users FROM GROUPS WHERE id=?',(9,)).fetchone()
conn.commit()
print(users)