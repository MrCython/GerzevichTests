function show(val){
    questions = document.getElementsByClassName('question')
    btn = document.getElementsByClassName('btn')
    for (let i=0;i<questions.length;i++){
        questions[i].style.display = "none";
        if (!btn[i].disabled){
            btn[i].style.background = "cadetblue";
        }
        if (i+1==val){
            btn[i].style.background = "gray";
        }
    }
    question = document.getElementById(val);
    question.style.display = "";
}
function save(k){
    btn_num = document.getElementsByClassName('btn')[k-1];
    btn = document.getElementsByClassName('btn_save')[k-1];
    question = document.getElementsByClassName('answer')[k-1];
    id = document.getElementsByClassName('ids')[k-1];
    btn.style.background = "#82b2e9";
    btn.innerHTML="Cохранено";
    btn_num.style.background = "#337ab7";
    btn_num.disabled = true;
    btn.disabled = true;
    id.disabled = true;
    question.disabled = true;
}
function get_result(){
    ids = document.getElementsByClassName('ids');
    btn = document.getElementsByClassName('btn_save');
    input = document.getElementsByClassName('answer');
    for (let i=0;i<ids.length;i++){
        input[i].disabled=!input[i].disabled;
        ids[i].disabled=!ids[i].disabled;
    }
}