function select(k){
    var object = document.getElementsByClassName('object');
    for (let i=0;i<object.length;i++){
        object[i].style.display="none";
    }
    var div = document.getElementById('object_'+k);
    div.style.display = "";
    button = document.getElementById('add_test');
    button.disabled = false;
    button.style.background = "#0071f0";
}
    

function select_all(k){
    checkbox = document.getElementsByClassName('option_'+k);
    all = document.getElementById('all_'+k);
    for (let i=0;i<checkbox.length;i++){
        checkbox[i].checked = all.checked;
    }
}
function check_option(status,k){
    all = document.getElementById('all_'+k);
    if (!status){
        all.checked = false;
    }
    let checked = 0;
    checkbox = document.getElementsByClassName('option_'+k);
    for (let i=0;i<checkbox.length;i++){
        checked += checkbox[i].checked;
    }
    if (checkbox.length == checked){
        all.checked = true;
    }
}
(function($) {
    function setChecked(target) {
        var checked = $(target).find("input[type='checkbox']:checked").length;
        $(target).find('select option:first').html('Выберите группы');
    }
    $.fn.checkselect = function() {
        this.wrapInner('<div class="checkselect-popup"></div>');
        this.prepend(
            '<div class="checkselect-control">' +
                '<select class="form-control"><option></option></select>' +
                '<div class="checkselect-over"></div>' +
            '</div>'
        );	
        this.each(function(){
            setChecked(this);
        });		
        this.find('input[type="checkbox"]').click(function(){
            setChecked($(this).parents('.checkselect'));
        });
        this.parent().find('.checkselect-control').on('click', function(){
            $popup = $(this).next();
            $('.checkselect-popup').not($popup).css('display', 'none');
            if ($popup.is(':hidden')) {
                $popup.css('display', 'block');
                $(this).find('select').focus();
            } else {
                $popup.css('display', 'none');
            }
        });
        $('html, body').on('click', function(e){
            if ($(e.target).closest('.checkselect').length == 0){
                $('.checkselect-popup').css('display', 'none');
            }
        });
    };
})(jQuery);	

function del_zero(){
    numbers = document.getElementsByClassName('num');
    types = document.getElementsByClassName('types');
    for (let i=0;i<numbers.length;i++){
        if (numbers[i].value == 0){
            numbers[i].disabled = true;
            types[i].disabled = true;
        }
    }
}