function select(object_topic_type,name,k){
    elem = document.getElementById('value_'+k);
    elem.value = object_topic_type;
    summary = document.getElementById('field_'+k);
    summary.innerHTML=name;
    details = document.getElementById(k);
    details.open = false;
    if (k=='0'){
        button = document.getElementById('add_question');
        button.disabled = false;
        button.style.background = "#0071f0";
    }
}
function search(){
    table = document.getElementById("myTable");
    tr = table.getElementsByTagName("tr");
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    for (i = 1; i < tr.length; i++) {
        text = document.getElementsByClassName("id")[i-1].innerHTML;
        if (text.toUpperCase().indexOf(filter) > -1) {
            tr[i].style.display = "";
        } else {
            tr[i].style.display = "none";
        }
    }
}