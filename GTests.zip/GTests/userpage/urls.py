from django.urls import path
from . import views 

urlpatterns = [
    path('login/',views.enter),
    path('',views.select),
    path('klass/',views.klass),
    path('tests/',views.tests),
    path('test/',views.test),
]