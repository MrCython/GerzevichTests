from random import *
import csv,os,sqlite3,re,time,os.path


class models:
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ПРОВЕРКА ЛОГИНА И ПАРОЛЯ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def check_log_pass(login,password):
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        cur.execute('DELETE FROM SESSION_USERS WHERE kill_time<?',(int(time.time()),))
        id=cur.execute('SELECT id FROM  USERS WHERE login=? AND password=?',(login,password)).fetchone()
        if type(id)!=tuple:
            answer=False
        else:
            offline=cur.execute('SELECT id FROM SESSION_USERS WHERE id=?',(id[0],)).fetchone()
            if type(offline)!=tuple:
                cur.execute('INSERT INTO SESSION_USERS VALUES(?,?)',(id[0],int(time.time())+3600*2))
                answer=id[0]
            else:
                answer=False
        conn.commit()
        return answer
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ПРОВЕРКА СЕССИИ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def check_session(id):
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        cur.execute('DELETE FROM SESSION_USERS WHERE kill_time<?',(int(time.time()),)) #Удаление истекших сессий
        online=cur.execute('SELECT id FROM SESSION_USERS WHERE id=?',(id,)).fetchone()
        conn.commit()
        answer=(type(online)==tuple)
        return answer
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~УДАЛЕНИЕ СЕССИИ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def del_session(id):
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        cur.execute('DELETE FROM SESSION_USERS WHERE id=?',(id,))
        conn.commit()
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ПОЛУЧЕНИЕ ФАМИЛИИ, ИМЕНИ ПО ID~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def get_surname_name(id):
        if id==None:
            return 'Неизвестный пользователь'
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        surname_name=cur.execute('SELECT surname_name FROM USERS WHERE id=?',(id,)).fetchone()
        conn.commit()
        return surname_name[0]
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~СПИСОК ГРУПП~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def list_groups(id):
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        if id==None:
            groups=cur.execute('SELECT id,name,avatar FROM GROUPS').fetchall()
        else:   
            surname_name=cur.execute('SELECT surname_name FROM USERS WHERE id=?',(id,)).fetchone()[0]
            groups=cur.execute('SELECT id,name,avatar FROM groups WHERE users LIKE ?',(f'%{surname_name}%',)).fetchall()
        conn.commit()
        return groups
    def get_name_group(id):
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        group=cur.execute('SELECT id,name FROM GROUPS WHERE id=?',(id,)).fetchone()
        conn.commit()
        return group
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ЗАПИСИ ГРУППЫ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def get_posts(id):
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        posts=cur.execute('SELECT date,name,text,fix FROM POSTS WHERE id_group=? ORDER BY fix,date DESC',(id,)).fetchall()
        conn.commit()
        return posts
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~СПИСОК ТЕСТОВ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~# 
    def list_tests(id):
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        surname_name=cur.execute('SELECT surname_name FROM USERS WHERE id=?',(id,)).fetchone()[0]
        groups=cur.execute('SELECT id FROM groups WHERE users LIKE ?',(f'%{surname_name}%',)).fetchall()
        groups={str(i[0]) for i in groups}|{'*'}
        objects=cur.execute('SELECT name,id FROM OBJECTS').fetchall()
        result={}
        for object in objects:
            tests=cur.execute('SELECT * FROM TESTS WHERE id_object=? AND active=1',(object[1],)).fetchall()
            tests=[i for i in tests if not(groups.isdisjoint(set(i[4].split(', '))))]
            result[object]=tests
        conn.commit()
        return result
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ПОДБОР ВОПРОСОВ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def get_questions(id):
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        types=cur.execute('SELECT questions FROM TESTS WHERE id=?',(id,)).fetchone()[0]
        types=dict([i.split(': ') for i in types.split(', ')[1:-1]])
        result=[]
        for type in types:
            questions=cur.execute('SELECT id,question FROM QUESTIONS WHERE id_type=?',(int(type),)).fetchall()
            result+=sample(questions,int(types[type]))
        shuffle(result)
        result=[[i+1]+list(result[i]) for i in range(len(result))]
        conn.commit()
        return result
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ИНфОРМАЦИЯ О ТЕСТАХ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def get_test(id):
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        test=cur.execute('SELECT id,name FROM TESTS WHERE id=?',(id,)).fetchone()
        conn.commit()
        return test
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~РЕЗУЛЬТАТ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def get_result(test,answers,time_test,id_user):
        right_answers=0
        conn = sqlite3.connect('db.sqlite3')
        cur = conn.cursor()
        surname_name=cur.execute('SELECT surname_name FROM USERS WHERE id=?',(id_user,)).fetchone()[0]
        for id in answers:
            answer=cur.execute('SELECT answer FROM QUESTIONS WHERE id=?',(id,)).fetchone()[0]
            if answer.strip()==answers[id].strip():
                right_answers+=1
        all_answers=cur.execute('SELECT questions FROM TESTS WHERE id=?',(test,)).fetchone()[0]
        cur.execute('UPDATE TESTS SET result=1 WHERE id=?',(test,))
        conn.commit()
        all_answers=sum([int(i.split(': ')[1]) for i in all_answers.split(', ')[1:-1]])
        if len(answers)>0:
            result=(all_answers,len(answers),right_answers,round(right_answers/len(answers),2)*100,time_test//3600,time_test%3600//60,time_test%3600%60)
        else:
            result=(all_answers,len(answers),right_answers,0,time_test//3600,time_test%3600//60,time_test%3600%60)
        time_format=''
        if time_test//3600<10: time_format+='0'
        time_format+=str(time_test//3600)+':'
        if time_test%3600//60<10: time_format+='0'
        time_format+=str(time_test%3600//60)+':'
        if time_test%3600%60<10: time_format+='0'
        time_format+=str(time_test%3600%60)
        path=f'{test}.csv'
        data=[['','']+list(answers.keys()),[surname_name,time_format]+list(answers.values())]
        helper.csv_writer(data,path)
        return result

class helper:
    def csv_writer(data, path):
        """
        Write data to a CSV file path
        """
        if not(os.path.isfile(os.path.join('static/results',path))):
            with open(os.path.join('static/results',path), "a", newline='') as csv_file:
                writer = csv.writer(csv_file, delimiter=',')
                writer.writerow(['Фамилия имя','Время'])
        else:
            with open(os.path.join('static/results',path), "a", newline='') as csv_file:
                writer = csv.writer(csv_file, delimiter=',')
                writer.writerow([''])
        with open(os.path.join('static/results',path), "a", newline='') as csv_file:
            writer = csv.writer(csv_file, delimiter=',')
            for line in data:
                writer.writerow(line)